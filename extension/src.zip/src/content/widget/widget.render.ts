import type { VintedItem } from "../../types"
import { api } from "../api/api"
import { setPrefill } from "../prefill/prefill"
const UPLOADS_URL = import.meta.env.VITE_API_URL

export async function renderStoredItems() {
	const list = document.getElementById("vr-list")!
	list.innerHTML = `<p style="font-size:12px;color:#aaa;margin:0;text-align:center;">Chargement...</p>`

	let items: VintedItem[]
	try {
		items = await api.getDueItems()
	} catch {
		list.innerHTML = `<p style="font-size:12px;color:red;margin:0;text-align:center;">Erreur de connexion au serveur</p>`
		return
	}

	if (items.length === 0) {
		list.innerHTML = `<p style="font-size:12px;color:#aaa;margin:0;text-align:center;">Aucun article sauvegardé</p>`
		return
	}

	list.innerHTML = (await Promise.all(items.map(renderItem))).join("")

	list.querySelectorAll(".vr-republish-btn").forEach((btn) => {
		btn.addEventListener("click", () => {
			const id = +(btn as HTMLElement).dataset.id!
			const item = items.find((i) => i.id === id)!
			republish(item)
		})
	})

	list.querySelectorAll(".vr-delete-btn").forEach((btn) => {
		btn.addEventListener("click", async () => {
			const id = +(btn as HTMLElement).dataset.id!
			await api.deleteItem(id)
			await renderStoredItems()
		})
	})
}

async function loadImageWithNgrok(url: string): Promise<string> {
	const isNgrok = url.includes("ngrok")
	if (!isNgrok) return url

	const res = await fetch(url, {
		headers: { "ngrok-skip-browser-warning": "true" },
	})
	const blob = await res.blob()
	return URL.createObjectURL(blob)
}

async function renderItem(item: VintedItem) {
	const firstPhoto = item.photos[0] ? await loadImageWithNgrok(`${UPLOADS_URL}/uploads/${item.photos[0].filename}`) : null
	return `
    <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #f0f0f0;">
      ${firstPhoto ? `<img src="${firstPhoto}" style="width:36px;height:36px;object-fit:cover;border-radius:4px;">` : ""}
      <div style="flex:1;min-width:0;">
        <p style="margin:0;font-size:12px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${item.title}</p>
        <p style="margin:0;font-size:11px;color:#888;">${item.price}</p>
      </div>
      <button data-id="${item.id}" class="vr-republish-btn" style="background:#09b1ba;color:white;border:none;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;display:flex;align-items:center;justify-content:center;">
        Republier
      </button>
			<button data-id="${item.id}" class="vr-delete-btn" style="background:none;border:none;cursor:pointer;font-size:14px;padding:4px;" title="Supprimer">
          🗑️
      </button>
    </div>
  `
}

async function republish(item: VintedItem) {
	await setPrefill(item)
	window.location.href = "https://www.vinted.fr/items/new"
}
