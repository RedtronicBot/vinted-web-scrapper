function findBreadcrumbInJsonLd(node: unknown): string[] | null {
	if (!node || typeof node !== "object") return null
	const obj = node as Record<string, unknown>
	if (obj["@type"] === "BreadcrumbList" && Array.isArray(obj.itemListElement)) {
		return (obj.itemListElement as Record<string, unknown>[])
			.sort((a, b) => Number(a.position) - Number(b.position))
			.map((el) => String(el.name ?? (el.item as Record<string, unknown> | undefined)?.name ?? ""))
	}
	for (const value of Object.values(obj)) {
		const found = findBreadcrumbInJsonLd(value)
		if (found) return found
	}
	return null
}

export function fetchCategoryFromPage(): string[] {
	const title = (document.querySelector("h1")?.textContent ?? "").trim().toLowerCase()
	let names: string[] = []

	// 1. Données structurées de la page
	for (const script of Array.from(document.querySelectorAll('script[type="application/ld+json"]'))) {
		try {
			const found = findBreadcrumbInJsonLd(JSON.parse(script.textContent ?? ""))
			if (found && found.length > 1) {
				names = found
				break
			}
		} catch {}
	}

	// 2. Sinon, le fil d'Ariane affiché
	if (names.length === 0) {
		const selectors = [".breadcrumbs__item", '[data-testid*="breadcrumb"] a', 'nav[aria-label*="riane"] a', '[class*="readcrumb"] a']
		for (const selector of selectors) {
			const items = Array.from(document.querySelectorAll(selector))
			if (items.length > 1) {
				names = items.map((el) => el.querySelector("span")?.textContent ?? el.textContent ?? "")
				break
			}
		}
	}

	names = names.map((n) => n.trim()).filter(Boolean)
	if (names[0]?.toLowerCase() === "accueil") names.shift()

	// On retire le dernier élément seulement si c'est le titre de l'annonce
	const last = names[names.length - 1]?.toLowerCase()
	if (last && title && (title.includes(last) || last.includes(title))) names.pop()

	return names
}
