export interface Photo {
	id: number
	filename: string
	position: number
	createdAt: string
	itemId: number
}

export interface VintedItem {
	id?: number
	title: string
	price: string
	brand: string
	size: string
	status: string
	description: string
	color: string
	createdAt?: string
	photos: Photo[]
	category: string[]
	material: string
	dimensions?: { width: string; length: string } | null
	reuploadAt: string
	sourceUrl: string
}

export type VintedItemPayload = Omit<VintedItem, "id" | "createdAt" | "photos"> & {
	photos: { src: string; position: number }[]
}
